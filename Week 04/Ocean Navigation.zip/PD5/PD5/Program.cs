﻿using System;
using System.Collections.Generic;

namespace PD5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Clear();
            string option;
            List<Ship> ships = new List<Ship>();
            do
            {
                option = menu();
                menuOptions(option, ships);
            } 
            while (option != "5");
        }
        static string menu()
        {
            Header();
            Console.WriteLine("\t\tMain Menu");
            Console.WriteLine("\t---------------------------------------");
            Console.WriteLine("\t1. Add Ship                   ");
            Console.WriteLine("\t2. View Ship Position         ");
            Console.WriteLine("\t3. View Ship Serial Number    ");
            Console.WriteLine("\t4. Change Ship Position       ");
            Console.WriteLine("\t5. Exit                       ");
            Console.Write("\t   Enter your choice  : ");
            string choice = Console.ReadLine();
            return choice;
        }
        static void menuOptions(string choice, List<Ship> ships)
        {
            if (choice == "1")
            {
                addShip(ships);
            }
            if (choice == "2")
            {
                printPosition(ships);
            }
            if (choice == "3")
            {
                viewShip(ships);
            }
            if (choice == "4")
            {
                changePosition(ships);
            }
            if (choice == "5")
            {
                Environment.Exit(0);
            }
        }
        static void addShip(List<Ship> ships)
        {
            Header();
            Console.Write("\tEnter Ship Number            : ");
            string number = Console.ReadLine();

            Console.WriteLine("\t*-----------------------------------*");
            Console.WriteLine("\t\tEnter Ship Latitude  ");
            Console.WriteLine("\t*-----------------------------------*");
            Console.Write("\tEnter Latitude's Degree      : ");
            int latDeg = int.Parse(Console.ReadLine());
            Console.Write("\tEnter Latitude's Minute      : ");
            float latMin = float.Parse(Console.ReadLine());
            Console.Write("\tEnter Latitude's Direction   : ");
            char latDir = char.Parse(Console.ReadLine());
            Angle latitude = new Angle(latDeg, latMin, latDir);

            Console.WriteLine("\t*-----------------------------------*");
            Console.WriteLine("\t\tEnter Ship Longitude  ");
            Console.WriteLine("\t*-----------------------------------*");
            Console.Write("\tEnter Longitude's Degree     : ");
            int Long_Deg = int.Parse(Console.ReadLine());
            Console.Write("\tEnter Longitude's Minute     : ");
            float Long_Min = float.Parse(Console.ReadLine());
            Console.Write("\tEnter Longitude's Direction  : ");
            char Long_Dir = char.Parse(Console.ReadLine());
            Angle longitude = new Angle(Long_Deg, Long_Min, Long_Dir);
            Ship newShip = new Ship(number, latitude, longitude);
            ships.Add(newShip);
        }
        static void printPosition(List<Ship> ships)
        {
            Header();
            Console.Write("\tEnter Ship Serial Number to find its position : ");
            string searchNumber = Console.ReadLine();

            foreach (Ship find in ships)
            {
                if (find.getSerialNum() == searchNumber)
                {
                    Header();
                    Console.WriteLine("\tShip Number   : {0}", searchNumber);
                    Console.WriteLine("\tShip Position : {0}", find.getPosition());
                    break;
                }
            }
            Console.Read();
        }
        static void viewShip(List<Ship> ships)
        {
            Header();
            Console.WriteLine("\t*-----------------------------------*");
            Console.WriteLine("\t\tEnter Ship Latitude     ");
            Console.WriteLine("\t*-----------------------------------*");
            Console.Write("\tEnter Latitude's Degree    : ");
            int latDeg = int.Parse(Console.ReadLine());
            Console.Write("\tEnter Latitude's Minute    : ");
            float latMin = float.Parse(Console.ReadLine());
            Console.Write("\tEnter Latitude's Direction : ");
            char latDir = char.Parse(Console.ReadLine());
            Angle latitude = new Angle(latDeg, latMin, latDir);

            Console.WriteLine("\t*-----------------------------------*");
            Console.WriteLine("\t\tEnter Ship Longitude  ");
            Console.WriteLine("\t*-----------------------------------*");
            Console.Write("\tEnter Longitude's Degree    : ");
            int Long_Deg = int.Parse(Console.ReadLine());
            Console.Write("\tEnter Longitude's Minute    : ");
            float Long_Min = float.Parse(Console.ReadLine());
            Console.Write("\tEnter Longitude's Direction : ");
            char Long_Dir = char.Parse(Console.ReadLine());
            Angle longitude = new Angle(Long_Deg, Long_Min, Long_Dir);

            Ship ship = FindShipByPosition(latitude, longitude, ships);

            if (ship != null)
            {
                Header();
                Console.WriteLine("\tSerial Number of Ship is : {0}", ship.getSerialNum());
            }
            else
            {
                Header();
                Console.WriteLine("\t! Ship is not found...");
            }
            Console.ReadKey();
        }

        static void changePosition(List<Ship> ships)
        {
            Header();
            Console.Write("\tEnter Ship's serial number whose position you want to change : ");
            string number = Console.ReadLine();
            Ship ship = FindShipByNumber(number, ships);

            if (ship != null)
            {
                Header();
                Console.WriteLine("\t*-----------------------------------*");
                Console.WriteLine("\t\tEnter Ship Latitude  ");
                Console.WriteLine("\t*-----------------------------------*");
                Console.Write("\tEnter Latitude's Degree    : ");
                int latDeg = int.Parse(Console.ReadLine());
                Console.Write("\tEnter Latitude's Minute    : ");
                float latMin = float.Parse(Console.ReadLine());
                Console.Write("\tEnter Latitude's Direction : ");
                char latDir = char.Parse(Console.ReadLine());
                ship.latitude = new Angle(latDeg, latMin, latDir);
                Console.WriteLine("\t*-----------------------------------*");
                Console.WriteLine("\t\tEnter Ship Longitude  ");
                Console.WriteLine("\t*-----------------------------------*");
                Console.Write("\tEnter Longitude's Degree    : ");
                int Long_Deg = int.Parse(Console.ReadLine());
                Console.Write("\tEnter Longitude's Minute    : ");
                float Long_Min = float.Parse(Console.ReadLine());
                Console.Write("\tEnter Longitude's Direction : ");
                char Long_Dir = char.Parse(Console.ReadLine());
                ship.longitude = new Angle(Long_Deg, Long_Min, Long_Dir);
                Console.WriteLine("\t"+$"Ship {number} position updated.");
            }
            else
            {
                Header();
                Console.WriteLine("\t"+$"Ship {number} is not found.");
            }
            Console.ReadKey();
        }
        static Ship FindShipByNumber(string number, List<Ship> ships)
        {
            foreach (Ship ship in ships)
            {
                if (ship.getSerialNum() == number)
                {
                    return ship;
                }
            }
            return null;
        }
        static Ship FindShipByPosition(Angle latitude, Angle longitude, List<Ship> ships)
        {
            foreach (Ship ship in ships)
            {
                if (ship.latitude.degrees == latitude.degrees && ship.latitude.minutes == latitude.minutes && ship.latitude.direction == latitude.direction
                    && ship.longitude.degrees == longitude.degrees && ship.longitude.minutes == longitude.minutes && ship.longitude.direction == longitude.direction)
                {
                    return ship;
                }
            }
            return null;
        }
        static void Header()
        {
            Console.Clear();
            Console.WriteLine("\t\t\t\t***********************************************************************");
            Console.WriteLine("\t\t\t\t***********************- Ship Managment System -***********************");
            Console.WriteLine("\t\t\t\t***********************************************************************");
            Console.WriteLine("\n\n");
        }
    }
}