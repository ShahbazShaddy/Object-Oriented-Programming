﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PD5
{
    class Angle
    {
        public int degrees;
        public float minutes;
        public char direction;
        public Angle(int degrees, float minutes, char direction)
        {
            this.degrees = degrees;
            this.minutes = minutes;
            this.direction = direction;
        }
        public void changeAngle(int degrees, float minutes, char direction)
        {
            this.degrees = degrees;
            this.minutes = minutes;
            this.direction = direction;
        }
        public string displayAngle()
        {
            string position = $"{degrees}\u00b0 {minutes}' {direction}";
            return position;
        }
    }
    class Ship
    {
        public string serialNum;
        public Angle latitude;
        public Angle longitude;
        public Ship(string serialNum, Angle latitude, Angle longitude)
        {
            this.serialNum = serialNum;
            this.latitude = latitude;
            this.longitude = longitude;
        }
        public string getPosition()
        {
            string position = $"{latitude.displayAngle()} and {longitude.displayAngle()}";
            return position;
        }
        public string getSerialNum()
        {
            return serialNum;
        }
        public void SetPosition(Angle latitude, Angle longitude)
        {
            this.latitude = latitude;
            this.longitude = longitude;
        }
    }
}
